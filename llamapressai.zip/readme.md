# LlamaPress AI Theme
A minimal WordPress theme using Tailwind CSS.

## Features
- Tailwind CSS for styling
- Clean, minimal design
- WordPress standard compliant
